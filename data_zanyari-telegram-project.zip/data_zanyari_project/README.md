# data_zanyari + Telegram Bot

GitHub Pages can host the frontend, but it cannot run the Node.js API/Telegram bot. Deploy `server.js` on a Node.js host and set the frontend `API` constant in `index.html` to that backend URL (for example `https://your-api.example.com`).

## Setup
1. Copy `.env.example` to `.env`.
2. Put the Telegram bot token in `.env` as `BOT_TOKEN=...`.
3. Run `npm install` then `npm start`.
4. Do **not** upload `.env` or `db.json` to GitHub.

The name search requires at least two words and uses the message: `تکایە ناوی دوانی یان سیانی بنووسە.` for a one-word query.
