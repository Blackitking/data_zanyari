require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');
const { Bot } = require('grammy');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({limit:'1mb'}));
const DB = path.join(__dirname,'db.json');
const PORT = Number(process.env.PORT || 3000);

const normalizeName = v => String(v || '').toLowerCase().replace(/[ًٌٍَُِّْـ]/g,'').replace(/[يى]/g,'ی').replace(/[ك]/g,'ک').replace(/[ۀة]/g,'ە').replace(/\s+/g,' ').trim();
const normalizePhone = v => String(v || '').replace(/[^\d+]/g,'');
function load(){ try { return JSON.parse(fs.readFileSync(DB,'utf8')); } catch { return []; } }
function save(data){ fs.writeFileSync(DB, JSON.stringify(data,null,2)); }
let people = load();

app.get('/api/search/name',(req,res)=>{
  const q=normalizeName(req.query.q);
  const words=q.split(/\s+/).filter(Boolean);
  if(words.length<2) return res.json({message:'تکایە ناوی دوانی یان سیانی بنووسە.',results:[]});
  const results=people.filter(p=>{
    const nw=normalizeName(p.name).split(/\s+/).filter(Boolean);
    return words.every(w=>nw.some(x=>x.startsWith(w)));
  });
  res.json({results});
});
app.get('/api/search/phone',(req,res)=>{
  const q=normalizePhone(req.query.q);
  if(!q) return res.json({message:'ژمارەی تەلەفون بنووسە.',results:[]});
  res.json({results:people.filter(p=>{const x=normalizePhone(p.phone);return x && x.includes(q);})});
});

app.post('/api/admin/add',(req,res)=>{
  if(req.get('x-admin-code') !== (process.env.ADMIN_CODE || '5624')) return res.status(401).json({error:'Unauthorized'});
  const name=String(req.body.name||'').trim(), phone=String(req.body.phone||'').trim(), more=String(req.body.more||'').trim();
  if(!name && !phone) return res.status(400).json({error:'تکایە ناو یان ژمارەی تەلەفون بنووسە.'});
  if(name && people.some(p=>normalizeName(p.name)===normalizeName(name))) return res.status(409).json({error:'ببورە، ئەم ناوە دوبارەیە.'});
  if(phone && people.some(p=>normalizePhone(p.phone)===normalizePhone(phone))) return res.status(409).json({error:'ببورە، ئەم ژمارەی تەلەفونە دوبارەیە.'});
  people.push({name,phone,more}); save(people); res.json({ok:true});
});

app.get('/api/admin/list',(req,res)=>{
  if(req.get('x-admin-code') !== (process.env.ADMIN_CODE || '5624')) return res.status(401).json({error:'Unauthorized'});
  res.json({results:people});
});

app.listen(PORT,()=>console.log(`API listening on port ${PORT}`));

if(process.env.BOT_TOKEN){
  const bot=new Bot(process.env.BOT_TOKEN);
  bot.command('start',ctx=>ctx.reply('بەخێربێیت. ناوی دوانی یان سیانی بنووسە بۆ گەڕان، یان ژمارەی تەلەفون بنووسە.'));
  bot.on('message:text',async ctx=>{
    const q=ctx.message.text.trim();
    const phone=normalizePhone(q);
    let results=[];
    if(/^\+?[0-9\s\-()]+$/.test(q) && phone.length>=3){
      results=people.filter(p=>{const x=normalizePhone(p.phone);return x && x.includes(phone);});
    } else {
      const words=normalizeName(q).split(/\s+/).filter(Boolean);
      if(words.length<2) return ctx.reply('تکایە ناوی دوانی یان سیانی بنووسە.');
      results=people.filter(p=>{const nw=normalizeName(p.name).split(/\s+/).filter(Boolean);return words.every(w=>nw.some(x=>x.startsWith(w)));});
    }
    if(!results.length) return ctx.reply('هیچ تۆمارێک نەدۆزرایەوە.');
    const out=results.slice(0,20).map(p=>`ناو: ${p.name||'—'}${p.phone?`\n📞 ${p.phone}`:''}${p.more?`\n${p.more}`:''}`).join('\n\n');
    await ctx.reply(out);
  });
  bot.start();
  console.log('Telegram bot started');
} else console.log('BOT_TOKEN not set; Telegram bot is disabled.');
