پڕۆژەی Website + Telegram Bot

1) Node.js دابەزێنە.
2) لە ناو ئەم فولدەرە:
   npm install
3) .env.example بکە بە .env
4) TELEGRAM_BOT_TOKEN ـەکەت لە .env دابنێ.
5) npm start
6) سایت: http://localhost:3000

تێبینی:
- index.html هەمان فایلەی پێشوویە و دەستکاری ناوەڕۆکی ئەسڵی نەکراوە.
- bot.js داتاکان لە db.json دەخوێنێتەوە.
- localStorage ـی براوزەکە خۆکارانە نابێتە db.json؛ ئەگەر داتای کۆنت لە localStorage ـە، پێویستە یەکجار export/import بکرێت بۆ db.json.
- Bot Token نهێنییە و نابێت لەگەڵ کەسێک هاوبەش بکرێت.
