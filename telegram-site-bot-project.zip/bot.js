const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const token = process.env.TELEGRAM_BOT_TOKEN;
if(!token || token === 'PASTE_YOUR_BOT_TOKEN_HERE') {
  console.error('TELEGRAM_BOT_TOKEN دانەنراوە.');
  process.exit(1);
}

const DB_FILE = path.join(__dirname, 'db.json');
const bot = new TelegramBot(token, {polling:true});

function loadPeople(){
  try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')).people || []; }
  catch { return []; }
}
function normalizeName(v){
  return String(v||'').toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g,'').replace(/[يى]/g,'ی')
    .replace(/[ك]/g,'ک').replace(/[ۀة]/g,'ە')
    .replace(/\s+/g,' ').trim();
}
function normalizePhone(v){ return String(v||'').replace(/[^\d+]/g,''); }
function format(p){
  let s = `👤 ${p.name || ''}`;
  if(p.phone) s += `\n📞 ${p.phone}`;
  if(p.more) s += `\n📝 ${p.more}`;
  return s;
}
function nameSearch(q){
  const words = normalizeName(q).split(/\s+/).filter(Boolean);
  if(words.length < 2) return null;
  return loadPeople().filter(p => {
    const nw = normalizeName(p.name).split(/\s+/).filter(Boolean);
    return words.every(w => nw.some(x => x.startsWith(w)));
  });
}
function phoneSearch(q){
  const x = normalizePhone(q);
  return loadPeople().filter(p => normalizePhone(p.phone).includes(x) && x);
}

bot.onText(/^\/start$/, msg => bot.sendMessage(msg.chat.id,
  'بەخێربێیت 👋\n\nبۆ گەڕان بە ناو، ناوی دوانی یان سیانی بنووسە.\nبۆ ژمارەی تەلەفون، ژمارەکە بنووسە.'
));

bot.on('message', msg => {
  if(!msg.text || msg.text.startsWith('/')) return;
  const q = msg.text.trim();
  const nameResults = nameSearch(q);
  if(nameResults !== null){
    if(!nameResults.length) return bot.sendMessage(msg.chat.id,'هیچ تۆمارێک نەدۆزرایەوە.');
    return bot.sendMessage(msg.chat.id, nameResults.slice(0,20).map(format).join('\n\n'));
  }
  const phoneResults = phoneSearch(q);
  if(phoneResults.length){
    return bot.sendMessage(msg.chat.id, phoneResults.slice(0,20).map(format).join('\n\n'));
  }
  bot.sendMessage(msg.chat.id,'تکایە ناوی دوانی یان سیانی، یان ژمارەی تەلەفون بنووسە.');
});

console.log('Telegram bot started.');
