const express = require('express');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'db.json');

app.use(express.json({limit: '2mb'}));
app.use(express.static(__dirname));

function loadPeople(){
  try {
    const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    return Array.isArray(data.people) ? data.people : [];
  } catch {
    return [];
  }
}

function savePeople(people){
  fs.writeFileSync(DB_FILE, JSON.stringify({people}, null, 2), 'utf8');
}

function normalizeName(value){
  return String(value || '')
    .toLowerCase()
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[يى]/g, 'ی')
    .replace(/[ك]/g, 'ک')
    .replace(/[ۀة]/g, 'ە')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizePhone(value){
  return String(value || '').replace(/[^\d+]/g, '');
}

function findByName(query){
  const words = normalizeName(query).split(/\s+/).filter(Boolean);
  if(words.length < 2) return {error:'تکایە ناوی دوانی یان سیانی بنووسە.'};
  const people = loadPeople();
  return {results: people.filter(person => {
    const nameWords = normalizeName(person.name).split(/\s+/).filter(Boolean);
    return words.every(word => nameWords.some(nameWord => nameWord.startsWith(word)));
  })};
}

function findByPhone(query){
  const input = normalizePhone(query);
  if(!input) return {results: []};
  const people = loadPeople();
  return {results: people.filter(person => {
    const phone = normalizePhone(person.phone);
    return phone !== '' && phone.includes(input);
  })};
}

app.get('/api/search/name', (req,res) => res.json(findByName(req.query.q || '')));
app.get('/api/search/phone', (req,res) => res.json(findByPhone(req.query.q || '')));
app.get('/api/people', (req,res) => res.json({people: loadPeople()}));

app.post('/api/people', (req,res) => {
  const name = String(req.body.name || '').trim();
  const phone = String(req.body.phone || '').trim();
  const more = String(req.body.more || '').trim();
  if(!name && !phone) return res.status(400).json({error:'تکایە ناو یان ژمارەی تەلەفون بنووسە.'});

  const people = loadPeople();
  if(name && people.some(p => normalizeName(p.name) === normalizeName(name)))
    return res.status(409).json({error:'ببورە، ئەم ناوە دوبارەیە.'});
  if(phone && people.some(p => normalizePhone(p.phone) === normalizePhone(phone)))
    return res.status(409).json({error:'ببورە، ئەم ژمارەی تەلەفونە دوبارەیە.'});

  const person = {name, phone, more};
  people.push(person);
  savePeople(people);
  res.json({ok:true, person});
});

app.listen(PORT, () => console.log(`Website/API: http://localhost:${PORT}`));
